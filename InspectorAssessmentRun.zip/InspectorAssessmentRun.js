'use strict';

/** do not make any changes to this, please feel free to contact rohit_duggal@mckinsey.com in case of any concerns.
 */

const AWS = require('aws-sdk');

const inspector = new AWS.Inspector();

const params = {
    assessmentTemplateArn: process.env.assessmentTemplateArn,
};

exports.handler = (event, context, callback) => {
    try {
        // Inspector.StartAssessmentRun response will look something like:
        // {"assessmentRunArn":"arn:aws:inspector:us-west-2:123456789012:target/0-wJ0KWygn/template/0-jRPJqnQh/run/0-Ga1lDjhP"
        inspector.startAssessmentRun(params, (error, data) => {
            if (error) {
                console.log(error, error.stack);
                return callback(error);
            }

            console.log(data);
            return callback(null, data);
        });
    } catch (error) {
        console.log('Caught Error: ', error);
        callback(error);
    }
};
