##Please contact rohit_duggal@mckinsey.com if any changes are needed. Else, do not change anything.
 
import boto3
import sys
import json
import logging
import cfnresponse

inspector_obj = boto3.client('inspector')
iam_obj = boto3.client('iam')
sns_obj = boto3.client('sns')
logger = logging.getLogger()
logger.setLevel(logging.INFO)
session = boto3.session.Session()
account_id = boto3.client("sts").get_caller_identity().get("Account")
region = session.region_name

def lambda_handler(event, context):
    
    #Fetching Security Inspector role details and assigning its arn to sir_arn
    
    roledetails= iam_obj.get_role(RoleName='Inspector')
    sir_arn = roledetails['Role']['Arn']
    
    # Creating a list of states which Inspector template can have. Also, storing root user ARN of different regions where inspector is supported
	
    sievents = ['ASSESSMENT_RUN_STARTED', 'ASSESSMENT_RUN_COMPLETED', 'ASSESSMENT_RUN_STATE_CHANGED','FINDING_REPORTED']
    root_arn = {'eu-west-1' : 'arn:aws:iam::357557129151:root', 'us-east-1':'arn:aws:iam::316112463485:root', 'us-west-1':'arn.aws.iam::166987590008:root', 'us-west-2':'arn:aws:iam::758058086616:root', 'ap-northeast-1':'arn:aws:iam::406045910587:root', 'ap-southeast-2':'arn:aws:iam::454640832652:root', 'ap-northeast-2':'arn:aws:iam::526946625049:root', 'ap-south-1':'arn:aws:iam::162588757376:root'}
    
    try:
        root_arn[region]
    except:
        sys.exit('Inspector is not supported in this region')
    
    #Register cross account access role if it is not already registered so that inspector service will be able to list tags present on different instances
    
    cross_account_access_role_arn = inspector_obj.describe_cross_account_access_role()
    if (str(cross_account_access_role_arn['valid']) != "True"):
        try:
            if(str(cross_account_access_role_arn['roleArn']) != sir_arn):
                logger.debug('Role assigned to inspector is:')
                logger.debug(str(cross_account_access_role_arn['roleArn']))
        except:
            inspector_obj.register_cross_account_access_role(
                roleArn= sir_arn
            )
    
    #Defining resource group for assesment. 
    
    resourcegroup = inspector_obj.create_resource_group(
        resourceGroupTags=[
            {
                'key': 'Inspector',
                'value': 'Yes'
            },
        ],
    ) 
    
    assessment_target= inspector_obj.create_assessment_target(
        assessmentTargetName='VS_Dev',
        resourceGroupArn= resourcegroup['resourceGroupArn']
        )
        
    # Creating assessment template which will run scan as per the listed rules
    
    rule_list = inspector_obj.list_rules_packages()
    assessment_template = inspector_obj.create_assessment_template(
        assessmentTargetArn = assessment_target['assessmentTargetArn'],
        assessmentTemplateName = 'VS_Dev_Template' ,
        durationInSeconds = 3600,
        rulesPackageArns = [
            rule_list['rulesPackageArns'][0],
            rule_list['rulesPackageArns'][1],
            rule_list['rulesPackageArns'][2],
            rule_list['rulesPackageArns'][3]
            ],
        )
    
	# Creating topic and subscription for subscribing to reports genarated by Security Inspector
    
    sns_sumo = sns_obj.create_topic(
        Name='SumoInspectorSNSTopic'
    )
    sns_notify = sns_obj.create_topic(
        Name='NotifyNerveSecurityTopic'
    )
    
    policy = json.dumps({
        "Version": "2008-10-17",
        "Id": "__default_policy_ID",
        "Statement": [
            {
                "Sid": "__default_statement_ID",
                "Effect": "Allow",
                "Principal": {
                "AWS": "*"
                },
                "Action": [
                    "SNS:Publish",
                    "SNS:RemovePermission",
                    "SNS:SetTopicAttributes",
                    "SNS:DeleteTopic",
                    "SNS:ListSubscriptionsByTopic",
                    "SNS:GetTopicAttributes",
                    "SNS:Receive",
                    "SNS:AddPermission",
                    "SNS:Subscribe"
                    ],
                "Resource": sns_sumo['TopicArn'],
            },
            {
                "Sid": "__console_pub_0",
                "Effect": "Allow",
                "Principal": {
                "AWS": [
                    root_arn[region]
                ]
                },
                "Action": "SNS:Publish",
                "Resource": sns_sumo['TopicArn']
            },
            {
                "Sid": "__console_sub_0",
                "Effect": "Allow",
                "Principal": {
                    "AWS": [
                        root_arn[region]
                    ]
                    },
                "Action": [
                    "SNS:Subscribe",
                    "SNS:Receive"
                ],
                "Resource": sns_sumo['TopicArn']
            }
        ]
    })
        
    sns_obj.set_topic_attributes(
        TopicArn=sns_sumo['TopicArn'],
        AttributeName="Policy",
        AttributeValue= policy
    )
    
    # Subscribing to Inspector Assessment Template events, this will send alert/reports as per the state of assessment template
    
    for i in sievents:    
        inspector_obj.subscribe_to_event(
            resourceArn= assessment_template['assessmentTemplateArn'],
            event= i,
            topicArn= sns_sumo['TopicArn']
        )
    
    policy = json.dumps({
        "Version": "2008-10-17",
        "Id": "__default_policy_ID",
        "Statement": [
            {
                "Sid": "__default_statement_ID",
                "Effect": "Allow",
                "Principal": {
                "AWS": "*"
                },
                "Action": [
                    "SNS:Publish",
                    "SNS:RemovePermission",
                    "SNS:SetTopicAttributes",
                    "SNS:DeleteTopic",
                    "SNS:ListSubscriptionsByTopic",
                    "SNS:GetTopicAttributes",
                    "SNS:Receive",
                    "SNS:AddPermission",
                    "SNS:Subscribe"
                    ],
                "Resource": sns_notify['TopicArn'],
            },
            {
                "Sid": "__console_pub_0",
                "Effect": "Allow",
                "Principal": {
                "AWS": [
                    root_arn[region]
                ]
                },
                "Action": "SNS:Publish",
                "Resource": sns_notify['TopicArn']
            },
            {
                "Sid": "__console_sub_0",
                "Effect": "Allow",
                "Principal": {
                    "AWS": [
                        root_arn[region]
                    ]
                    },
                "Action": [
                    "SNS:Subscribe",
                    "SNS:Receive"
                ],
                "Resource": sns_notify['TopicArn']
            }
        ]
    })
    
    sns_obj.set_topic_attributes(
        TopicArn=sns_notify['TopicArn'],
        AttributeName="Policy",
        AttributeValue= policy
    )
    
    inspector_obj.subscribe_to_event(
            resourceArn= assessment_template['assessmentTemplateArn'],
            event= sievents[1],
            topicArn= sns_notify['TopicArn']
        )
    responseData={"SumoInspectorSNSTopic":sns_sumo['TopicArn'],"NerveSecNotify":sns_notify['TopicArn'],"assessmentTemplateArn":assessment_template['assessmentTemplateArn']}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData, "CustomResourcePhysicalID")