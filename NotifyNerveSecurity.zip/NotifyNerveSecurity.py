##Please contact rohit_duggal@mckinsey.com if any changes are needed. Else, do not change anything.

import json
import httplib
import base64,zlib
import urlparse
import boto3
import datetime
import logging
import time
import wget
from datetime import datetime
import os
import tempfile
import sys

ses_obj = boto3.client("ses")
inspector_obj = boto3.client("inspector")
contextLookup = True
lambda_obj = boto3.client("lambda")
session = boto3.session.Session()
region = session.region_name
account_id = boto3.client("sts").get_caller_identity().get("Account")
S3_WEB_REPORT_EXPIRE = "168"
    
def lambda_handler(event, context):
    
    #Deleting Inspector_Initialize lambda which was created for intial setup of Inspector Service

    list_functions= lambda_obj.list_functions()
    index=0

    while index<len(list_functions['Functions']):
        function_att= list_functions['Functions'][index]
        if (function_att['FunctionName'] == 'Inspector_Initialize'):
            Inspector_Init='arn:aws:lambda:'+region+':'+account_id+':function:Inspector_Initialize'
            response=lambda_obj.delete_function(
                FunctionName=Inspector_Init
                )
        index=index+1
    
    if ('Records' in event):
        for record in event['Records']:
            # get actual SNS message
            snsObj = record['Sns']
            dataObj = {'Timestamp':snsObj['Timestamp'],'Message':snsObj['Message'],'MessageId':snsObj['MessageId']}
            msgObj = json.loads(snsObj['Message'])
            if (contextLookup):
                # do reverse lookup of each of the following items in Message: target, run, template.
                if ('run' in msgObj):
                    run_arn = msgObj['run']
    
   
    Inspector_Findings = inspector_obj.get_assessment_report(
        assessmentRunArn=run_arn,
        reportFileFormat= 'HTML',
        reportType='FINDING'
        )
    
    Inspector_Full_Report = inspector_obj.get_assessment_report(
        assessmentRunArn=run_arn,
        reportFileFormat='HTML',
        reportType='FULL'
        )
    
    Inspector_Findings_Name = "AWSInspector_Findings_" + str(account_id) + "_" + str(datetime.now()) + ".html"
    Inspector_Full_Report_Name = "AWSInspector_Full_Report_" + str(account_id) + "_" + str(datetime.now()) + ".html"
    
    FindingReportPath = "/tmp/" + Inspector_Findings_Name
    FullReportPath = "/tmp/" + Inspector_Full_Report_Name
    
    filename1 = wget.download(Inspector_Findings['url'], FindingReportPath)
    filename2 = wget.download(Inspector_Full_Report['url'], FullReportPath)
    
    nssBucketname= "nss-" + account_id + "-" + region
    CurrentDate= str(time.strftime("%c"))
    InspectorFindingsBucketPath= "reports/InspectorAssessmentReports/" + CurrentDate + "/" + Inspector_Findings_Name
    InspectorFullReportBucketPath= "reports/InspectorAssessmentReports/" + CurrentDate + "/" + Inspector_Full_Report_Name
    
    s3 = boto3.resource('s3')
    S3_CLIENT = boto3.client('s3')
    s3.meta.client.upload_file(FindingReportPath, nssBucketname, InspectorFindingsBucketPath)
    s3.meta.client.upload_file(FullReportPath, nssBucketname, InspectorFullReportBucketPath)

    ttl = int(S3_WEB_REPORT_EXPIRE) * 60
    InspectorFindingsURL = S3_CLIENT.generate_presigned_url(
        'get_object',
        Params={
            'Bucket': nssBucketname,
            'Key': InspectorFindingsBucketPath
        },
        ExpiresIn=ttl)
    
    InspectorFullReportURL = S3_CLIENT.generate_presigned_url(
        'get_object',
        Params={
            'Bucket': nssBucketname,
            'Key': InspectorFullReportBucketPath
        },
        ExpiresIn=ttl)
        
    SNS_TOPIC_ARN= "arn:aws:sns:"+region+":"+account_id+":nssTopic"
    client = boto3.client('sns', region_name=region)
    client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject="AWS Inspector Report - " + region + ' ' + str(time.strftime("%c")),
        Message='Greetings!'+'\n'+'\n'+'Detailed list of threats which were found this week is here:\n\n'+ nssBucketname + "/" + InspectorFindingsBucketPath +'\n\nFull Vulnerability Assessment Report is here:'+'\n\n'+ nssBucketname + "/" + InspectorFullReportBucketPath,
        MessageStructure='html'
    )