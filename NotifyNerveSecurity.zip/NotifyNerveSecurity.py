##Please contact rohit_duggal@mckinsey.com if any changes are needed. Else, do not change anything.

import json
import httplib
import base64,zlib
import urlparse
import boto3
import datetime
import logging
import time
import wget
from datetime import datetime
import os
import tempfile
import sys

ses_obj = boto3.client("ses")
inspector_obj = boto3.client("inspector")
contextLookup = True
lambda_obj = boto3.client("lambda")
session = boto3.session.Session()
region = session.region_name
account_id = boto3.client("sts").get_caller_identity().get("Account")
    
def lambda_handler(event, context):
    
    #Deleting Inspector_Initialize lambda which was created for intial setup of Inspector Service

    list_functions= lambda_obj.list_functions()
    index=0

    while index<len(list_functions['Functions']):
        function_att= list_functions['Functions'][index]
        if (function_att['FunctionName'] == 'Inspector_Initialize'):
            Inspector_Init='arn:aws:lambda:'+region+':'+account_id+':function:Inspector_Initialize'
            response=lambda_obj.delete_function(
                FunctionName=Inspector_Init
                )
        index=index+1
    
    if ('Records' in event):
        for record in event['Records']:
            # get actual SNS message
            snsObj = record['Sns']
            dataObj = {'Timestamp':snsObj['Timestamp'],'Message':snsObj['Message'],'MessageId':snsObj['MessageId']}
            msgObj = json.loads(snsObj['Message'])
            if (contextLookup):
                # do reverse lookup of each of the following items in Message: target, run, template.
                if ('run' in msgObj):
                    run_arn = msgObj['run']
    
    #run_arn = "arn:aws:inspector:us-east-1:623051559151:target/0-5s67icwb/template/0-dsIfHNvw/run/0-YA7uG9SL"
    
    Inspector_Findings = inspector_obj.get_assessment_report(
        assessmentRunArn=run_arn,
        reportFileFormat= 'HTML',
        reportType='FINDING'
        )
    
    Inspector_Full_Report = inspector_obj.get_assessment_report(
        assessmentRunArn=run_arn,
        reportFileFormat='HTML',
        reportType='FULL'
        )
    
    Inspector_Findings_Name = "AWSInspector_Findings_" + str(account_id) + "_" + str(datetime.now().strftime('%Y%m%d_%H%M')) + ".html"
    Inspector_Full_Report_Name = "AWSInspector_Full_Report_" + str(account_id) + "_" + str(datetime.now().strftime('%Y%m%d_%H%M')) + ".html"
    
    FindingReportPath = "/tmp/" + Inspector_Findings_Name
    FullReportPath = "/tmp/" + Inspector_Full_Report_Name
    
    filename1 = wget.download(Inspector_Findings, "report1.html")
    filename2 = wget.download(Inspector_Full_Report, "report2.html")
    
    bucketName= "nss-" + account_id + "-" + region
    bucketPath= bucketName + "/report/"
    s3 = boto3.resource('s3')
    s3.meta.client.upload_file("report1.html", bucketPath, Inspector_Findings_Name)
    s3.meta.client.upload_file("report2.html", bucketPath, Inspector_Full_Report_Name)
    
    SNS_TOPIC_ARN= "arn:aws:sns:"+region+":"+account_id+":nssTopic"
    client = boto3.client('sns', region_name=region)
    client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject="AWS Inspector Report - " + region + ' ' + str(time.strftime("%c")),
        Message='Greetings!'+'\n'+'\n'+'Detailed list of threats which were found this week:\n\n'+Inspector_Findings['url']+'\n\nFull Vulnerability Assessment Report:'+'\n\n'+Inspector_Full_Report['url'],
        MessageStructure='html'
    )
    
    Inspector_Full_Report = inspector_obj.get_assessment_report(
        assessmentRunArn=run_arn,
        reportFileFormat='HTML',
        reportType='FULL'
        )
    
    SNS_TOPIC_ARN= "arn:aws:sns:"+region+":"+account_id+":nssTopic"
    client = boto3.client('sns', region_name=region)
    client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject="AWS Inspector Report - " + region + ' ' + str(time.strftime("%c")),
        Message='Greetings!'+'\n'+'\n'+'Detailed list of threats which were found this week:\n\n'+Inspector_Findings['url']+'\n\nFull Vulnerability Assessment Report:'+'\n\n'+Inspector_Full_Report['url'],
        MessageStructure='html'
    )